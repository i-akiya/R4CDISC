library(testthat)
library(R4CDISC)

test_check("R4CDISC")
