getDSName <- function(Nodeset){
    getAttr( Nodeset=Nodeset, Attr="Name")  
}