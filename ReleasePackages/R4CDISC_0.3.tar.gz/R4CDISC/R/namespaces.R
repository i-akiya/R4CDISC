namespaces <- function(){
    return( c( ns = 'http://www.cdisc.org/ns/odm/v1.3', 
               def = 'http://www.cdisc.org/ns/def/v2.0' ) )
}