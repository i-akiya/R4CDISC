getDomain <- function(Nodeset){
    getAttr( Nodeset=Nodeset, Attr="Domain")  
}
